export default function AnalyticsPage() {
  return (
  <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Analytics</h1>
      </div>
      {/* Add content for Analytics page */}
    </div>
  )
}

