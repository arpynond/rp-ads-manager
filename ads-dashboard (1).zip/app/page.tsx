import { CampaignsList } from "@/components/campaigns-list"

export default function CampaignsPage() {
  return (
    <div>
      <CampaignsList />
    </div>
  )
}

