import { AdsList } from "@/components/ads-list"

export default function AdsPage() {
  return (
    <div>
      <AdsList />
    </div>
  )
}

