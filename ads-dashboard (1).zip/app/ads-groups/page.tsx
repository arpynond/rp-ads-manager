"use client"

import { AdsGroupsList } from "@/components/ads-groups-list"

export default function AdsGroupsPage() {
  return (
    <div>
      <AdsGroupsList />
    </div>
  )
}

