export default function SettingsPage() {
  return (
  <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Settings</h1>
      </div>
      {/* Add content for Settings page */}
    </div>
  )
}

